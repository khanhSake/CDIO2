﻿namespace GymBookingSystemAPI.DTOs
{
    public class UpdateFacilityDTO
    {
        public string FacilityName { get; set; }
        public string Description { get; set; }
        public string IconClass { get; set; }
    }
}