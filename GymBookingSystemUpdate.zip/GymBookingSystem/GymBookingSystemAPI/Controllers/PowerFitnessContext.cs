﻿namespace PowerFitness.Controllers
{
    internal class PowerFitnessContext
    {
    }
}